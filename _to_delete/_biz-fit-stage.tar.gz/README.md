# Matter Workbench

**Matter Workbench is an AI-assisted legal workbench that turns messy case documents into a structured, source-backed workspace lawyers can review and use.**

It is built for the first hard part of legal work: taking PDFs, emails, scans, spreadsheets, pleadings, notices, orders, and client material, then producing an auditable record with document labels, extracted text, a source index, matter context, and a lawyer-review-ready chronology.

> Status: **Beta 3 private-cloud beta is code-complete on `main`, deployed, with canonical custom-skill events and active source suppression/currentness foundations live across local and runtime DB read paths.**
>
> Access: **Private beta only.** This is not a public self-serve legal advice product; trusted testers use supervised accounts and lawyer review remains mandatory.

---

## Why This Exists

Legal AI is only useful when the lawyer can trust where each answer came from.

Matter Workbench is not a generic chatbot. It is closer to a disciplined junior chamber clerk:

1. preserve the incoming brief;
2. identify and fingerprint every source;
3. extract the record;
4. label documents in lawyer-readable language;
5. build source-backed matter artifacts;
6. keep every AI-assisted output reviewable by a lawyer.

The product goal is simple:

```text
messy matter folder -> structured legal workspace -> source-backed legal work product
```

---

## What It Does Today

### Matter Intake

- Upload or point the app at a matter folder.
- Preserve originals and assign stable document IDs.
- Detect duplicate files and unsafe upload paths.
- Keep matter metadata and file custody explicit.
- Archive and reopen closed matters without deleting source files or history.

### Extraction And Source Indexing

- Extract text from supported documents.
- Support OCR-first handling for scanned PDFs when configured.
- Produce source records and lawyer-readable source labels.
- Validate model output against server-owned file identity and citations.

### Case Timeline / Neutral Chronology

- Build a neutral Case Timeline from the matter record.
- Preserve source references for review.
- Flag stale dependencies and review needs.
- Keep generated legal artifacts separate from originals and dispatch-ready outputs.

### Matter Copilot

- Answer matter questions from bounded matter context.
- Fail closed on unsupported citations.
- Keep transient Q&A separate from durable legal artifacts.

### Custom Skills

- Let operators design reusable legal workflows.
- Generate samples, require review, and activate versioned custom skills.
- Preserve custom-skill run receipts for audit and improvement.

### Private Beta Operations

- Private beta login and tester accounts.
- In-app feedback capture.
- Operator/mothership reports for bugs, confusing UX, feature requests, and runtime signals.
- Read-only System Health for provider/config/runtime/storage posture.
- Runtime DB private-cloud deployment path with tenant-scoped Postgres migrations.

---

## Why It Is Different

### Source-backed by design

Matter Workbench treats citations, source identity, and artifact boundaries as product contracts, not prompt suggestions.

### Legal-review-ready, not lawyer-replacement

The app is designed to help lawyers review faster. It does not claim that generated output is court-ready without human verification.

### Workflow, not chat

Outputs are durable artifacts: source indexes, extracted records, case timelines, skill receipts, and diagnostic reports. Work does not disappear into a chat transcript.

### Local/private-cloud custody

The project supports a local-first workflow and a private-cloud runtime DB path. Legal data custody is explicit, tenant-scoped, and designed for controlled beta deployment.

### Feedback becomes product intelligence

Beta feedback, job traces, system health, and operator reports are being shaped into a governed improvement loop: evidence first, triage second, gated work third.

---

## Official Private Beta Release State

The current official supervised private beta release is recorded in the
[Current release pointer](docs/releases/current.md). It is feature-frozen unless
a blocker, regression, security/custody issue, or deployment failure appears.

All actionable tester feedback that could reasonably be solved in this release
window has been fixed, deployed, validated, or intentionally parked for a future
roadmap slice.

Completed release checks include:

- Postgres migration `020_matter_events` applied and recorded;
- `custom_skill.created` canonical Matter Log event wired for new custom skill activations;
- read-side active source suppression foundation wired before any file-removal UI;
- stale generated artifact summaries prevented from reintroducing suppressed source citations;
- runtime DB inactive source document statuses aligned with active-source suppression;
- local rerun/currentness advice marks Source Index/Case Timeline stale when suppressed sources are still referenced;
- runtime DB workspace/payload reads filter derived extraction/text payloads linked to inactive sources;
- artifact currentness schema/projection foundation exists for future source-removal workflows;
- non-routed source-removal mutation foundations, privilege-safe Matter Log rendering, a read-only impact preview endpoint, and non-destructive matter archive/reopen lifecycle exist, without source-delete/purge UI exposure;
- Case Timeline presentation, command, and artifact paths for the neutral chronology while preserving hidden legacy List of Dates compatibility;
- automatic provisional Filing and Procedural Posture Diagnosis after Case Timeline and Matter Story;
- lawyer confirmation/correction/not-sure controls for posture diagnosis;
- Assistant readiness degradation remains visible with sanitized user-facing copy;
- user-facing AI/provider errors are centralized behind a safe API and command-activity boundary;
- Matter Overview **Prepared** status now includes Matter Story and Filing and Procedural Posture Diagnosis readiness;
- default preparation reruns use **Run needed preparation**, with full rebuild behind a reason and `REBUILD` confirmation;
- private-cloud deployment to the beta VM;
- runtime DB migration through `025_processing_job_stage_kinds`;
- backend-owned post-upload preparation queueing through source labels, Case Timeline, Matter Story, and posture diagnosis;
- default runtime DB **Run needed preparation** uses backend jobs with React polling durable job status;
- Matter Overview observes backend preparation jobs after refresh/reconnect, shows **Preparation running on server…**, avoids duplicate preparation runs while jobs are active, and refreshes when server jobs finish;
- the backend preparation job observer lives in a dedicated React hook with a narrowed safe failure contract;
- Filing and Procedural Posture Diagnosis now renders a simple case view, probable legal routes, a recommended route, next best actions, and statutory-reference prompts;
- the posture diagnosis output contract, renderer, normalizers, prototype loop reuse, and Matter Overview summary are split into dedicated modules without changing beta.109 behavior;
- Matter Overview blocked/stale preparation rows show their backend reason instead of implying an output document is unexpectedly missing;
- stale Matter Story and procedural posture backend preparation jobs carry overwrite metadata so **Run needed preparation** can refresh stale artifacts and continue through unblocked downstream steps;
- native skill runner jobs/receipts are visible for posture, Matter Story, Case Timeline, and Source Labels;
- saved procedural diagnosis UX distinguishes chat-only answers from durable artifacts;
- Matter Preparation row actions expose Source Labels, Case Timeline, Matter Story, and saved Procedural Diagnosis refreshes without duplicate bottom buttons;
- login smoke;
- matter upload smoke;
- extraction, source labels, Case Timeline, Matter Story, and posture diagnosis smoke;
- Matter Copilot endpoint smoke;
- feedback submission and sync smoke;
- System Health smoke;
- browser UI hardening pass with zero console errors;
- runtime and mothership service checks.

Current release and repo-state docs:

- [Current release pointer](docs/releases/current.md)
- [Official private beta release decision](docs/private-beta-official-release.md)
- [Docs map](docs/README.md)
- [Release codenames](docs/release-codenames.md)
- [Repo branch/worktree hygiene](docs/repo-branch-hygiene.md)
- [Private beta runbook](docs/beta-user-runbook.md)
- [Database transition handoff](docs/database-transition-handoff.md)

---

## Architecture At A Glance

```text
React app
  -> Node local/private runtime server
    -> matter engines
    -> provider routing layer
    -> runtime DB storage mode
    -> private beta telemetry / feedback / health surfaces
```

Core surfaces:

- `react-ui/` - product shell and lawyer/operator UI.
- `routes/` - API route groups.
- `services/` - matter storage, model routing, health, skill, feedback, and runtime services.
- `db/migrations/` - Postgres control-plane and runtime DB migration track.
- `docs/contracts/` - current product/engineering contracts.
- `docs/future-design-decisions/` - parked roadmap and implementation decisions.

For a deeper codebase map, see [docs/codebase-diagram.md](docs/codebase-diagram.md).

---

## Safety And Governance

Matter Workbench is built around legal safety boundaries:

- no silent mutation of generated legal artifacts;
- server-owned source identity and citation validation;
- separation between raw originals, generated drafts, and dispatch-ready outputs;
- private beta authentication and operator-only diagnostic surfaces;
- tenant-scoped runtime DB posture;
- secret redaction in reports and telemetry;
- read-only first slices for cost, credit, and system health;
- human review before legal reliance.

Important: this beta is not a public self-serve legal advice product.

---

## Roadmap Themes

Near-term roadmap themes are documented rather than hidden in ad hoc issues:

- feedback-to-ticket improvement loops;
- observability-to-smaller-model cost reduction;
- broader native legal skill library;
- hosted beta worker architecture;
- richer document/source inventory;
- spreadsheet and communication evidence ingestion;
- governed credit/cost reporting;
- stronger runtime health and incident projection.

See:

- [Feedback-To-Improvement And Smaller Models](docs/future-design-decisions/feedback-to-improvement-and-smaller-models.md)
- [Native Skill Library Strategy](docs/future-design-decisions/native-skill-library-strategy.md)
- [Hosted Beta Database Architecture](docs/future-design-decisions/hosted-beta-database-architecture.md)
- [Credit System](docs/future-design-decisions/credit-system.md)

---

## Development Quickstart

```sh
npm install
npm test
npm run ui:build
npm start
```

Read-only local health:

```sh
npm run system-health:report
```

Database migration posture:

```sh
npm run db:migrations:check
npm run db:doctor
```

For the full technical README that previously lived at the repo root, see
[docs/engineering-readme-archive.md](docs/engineering-readme-archive.md).

---

## Investor / Partner Note

Matter Workbench is early, but the beta now demonstrates the core thesis:

```text
AI legal work becomes valuable when it is source-backed, workflow-native,
observable, and governed by reviewable product contracts.
```

The investment opportunity is not just another legal chatbot. It is a legal-work operating system that can accumulate workflow evidence, feedback, traces, and domain-specific process knowledge, then convert that into safer product automation and lower-cost specialised intelligence over time.

For partnership or investment conversations, review the product docs above and request a supervised beta walkthrough.
