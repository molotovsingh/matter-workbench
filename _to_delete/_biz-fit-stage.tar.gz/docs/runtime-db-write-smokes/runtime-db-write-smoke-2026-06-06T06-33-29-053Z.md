Matter Workbench runtime DB write smoke
passed: yes
mode: runtime DB live write smoke
database_url_source: MWB_RUNTIME_DATABASE_URL
tenant_id: 82dc5ad0-fb23-5c08-a06c-73232cd0281f
test_run_id: runtime-db-write-smoke-2026-06-06T06-33-29-053Z
matter_name: Runtime DB Write Smoke -06-06T06-33-29-053Z
role_guard_passed: yes
upload_created: yes
workspace_readable: yes
file_preview_readable: yes
raw_file_readable: yes
db_rows_verified: yes
rollback_verified: yes
cleanup_archived: yes
counts: {"documents":1,"matterCount":1,"payloadRows":2,"payloadBytes":514,"importBatches":1,"storageObjects":2,"activeMatterCount":1}
