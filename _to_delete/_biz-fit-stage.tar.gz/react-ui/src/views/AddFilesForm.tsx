import { useEffect, useState, useRef } from 'react';
import { useApp } from '../store/AppContext';
import { api } from '../api/client';
import { getErrorMessage } from '../lib/errors';
import { useLatestValue } from '../hooks/useLatestValue';
import type { OverlapWarning } from '../types';
import {
  collectDroppedEntries,
  collectFilesFromFileList,
  findDuplicateRelativePath,
  getDroppedFileSystemEntries,
  type CollectedUploadFile,
} from '../lib/uploadFileCollection';
import { assessUploadBatchSize, describeUploadBatchLimit } from '../lib/uploadBatchPreflight';
import { hashFilesSha256IfAvailable } from '../lib/browserFileHash';
import { reportUploadPrecheckUnavailable, reportUploadSubmitFailure } from '../lib/uploadClientTelemetry';
import { UploadSessionRecoveryCard } from '../components/upload/UploadSessionRecoveryCard';
import {
  addFilesWithUploadSession,
  cancelUploadSessionDraft,
  findLatestUploadSessionDraft,
  findMatchingUploadSessionDraft,
  type StoredUploadSessionDraft,
} from '../lib/uploadSessions';

interface Props {
  onCancel: () => void;
  onDone: (opts?: { autoPrepare?: boolean }) => void;
}

export default function AddFilesForm({ onCancel, onDone }: Props) {
  const { state, appendTerminal } = useApp();
  const activeMatterNameRef = useLatestValue(state.activeMatter?.name ?? null);
  const [collected, setCollected] = useState<CollectedUploadFile[]>([]);
  const [label, setLabel] = useState('');
  const [dragover, setDragover] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [progressMessage, setProgressMessage] = useState('');
  const [recoverableUpload, setRecoverableUpload] = useState<StoredUploadSessionDraft | null>(null);
  const [error, setError] = useState('');
  const [selfOverlap, setSelfOverlap] = useState<OverlapWarning | null>(null);
  const [otherOverlaps, setOtherOverlaps] = useState<OverlapWarning[]>([]);
  const [bypassOverlap, setBypassOverlap] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const folderInput = useRef<HTMLInputElement>(null);
  const runtimeUploadSessionsEnabled = state.config?.runtimeStorageMode === 'postgres';

  useEffect(() => {
    const matterName = state.activeMatter?.name;
    if (!runtimeUploadSessionsEnabled || !matterName) {
      setRecoverableUpload(null);
      return;
    }
    setRecoverableUpload(findLatestUploadSessionDraft({ action: 'add_files', matterName }));
  }, [runtimeUploadSessionsEnabled, state.activeMatter?.name]);

  function addFiles(files: CollectedUploadFile[]) {
    setCollected((prev) => [...prev, ...files]);
    setSelfOverlap(null);
    setOtherOverlaps([]);
    setBypassOverlap(false);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragover(false);
    const entries = getDroppedFileSystemEntries(e.dataTransfer);

    if (entries.length > 0) {
      collectDroppedEntries(entries).then(addFiles).catch((err) => setError(getErrorMessage(err)));
    } else {
      addFiles(collectFilesFromFileList(e.dataTransfer.files));
    }
  }

  function handleFileInput(e: React.ChangeEvent<HTMLInputElement>) {
    const input = e.currentTarget;
    const selectedFiles = collectFilesFromFileList(Array.from(input.files ?? []));
    if (selectedFiles.length > 0) {
      addFiles(selectedFiles);
    }
    window.setTimeout(() => {
      input.value = '';
    }, 0);
  }

  async function handleForgetRecoverableUpload() {
    if (!recoverableUpload) return;
    await cancelUploadSessionDraft(recoverableUpload);
    setRecoverableUpload(null);
    setError('');
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (collected.length === 0) { setError('Select at least one file.'); return; }
    const duplicatePath = findDuplicateRelativePath(collected);
    if (duplicatePath) {
      setError(`Multiple selected files would upload as "${duplicatePath}". Use Browse folder to preserve folders, or rename/remove duplicates before uploading.`);
      return;
    }
    const sizeCheck = assessUploadBatchSize(collected, state.config?.maxUploadBytes, state.config?.maxUploadFiles);
    if (!sizeCheck.ok) {
      setError(sizeCheck.message);
      return;
    }
    const matterName = state.activeMatter?.name;
    if (!matterName) return;
    setSubmitting(true);
    setError('');
    setProgressMessage('Checking selected files before upload…');

    try {
      if (!bypassOverlap) {
        setProgressMessage(`Checking ${collected.length} file(s) for duplicate records…`);
        appendTerminal(['[add-files] checking for duplicates…']);
        const hashes = await hashFilesSha256IfAvailable(collected.map((c) => c.file));
        if (activeMatterNameRef.current !== matterName) return;

        if (!hashes) {
          reportUploadPrecheckUnavailable({
            files: collected,
            matterName,
            view: 'add_files',
            action: 'add_files',
          });
          appendTerminal(['[add-files] Duplicate check is unavailable in this browser; uploading without duplicate warning.']);
        } else {
          const checkResult = await api.checkOverlap({
            hashes,
            proposedName: matterName,
          });
          if (activeMatterNameRef.current !== matterName) return;

          const warnings = checkResult.warnings ?? [];
          const self = warnings.find((w) => w.matterName === matterName);
          const others = warnings.filter((w) => w.matterName !== matterName);

          if (self || others.length > 0) {
            setSelfOverlap(self ?? null);
            setOtherOverlaps(others);
            setSubmitting(false);
            return;
          }
        }
      }

      setProgressMessage(state.config?.runtimeStorageMode === 'postgres'
        ? `Creating upload session for ${collected.length} file(s)…`
        : `Uploading ${collected.length} file(s) to this matter. Keep this page open; large folders can take a few minutes.`);
      appendTerminal([state.config?.runtimeStorageMode === 'postgres'
        ? `[add-files] creating durable upload session for ${collected.length} file(s)…`
        : `[add-files] uploading ${collected.length} file(s)…`]);

      const resumeDraft = findMatchingUploadSessionDraft({ action: 'add_files', matterName, files: collected });
      if (resumeDraft) {
        appendTerminal([`[add-files] resuming durable upload session ${resumeDraft.sessionId} for ${collected.length} file(s)…`]);
      }
      const result = state.config?.runtimeStorageMode === 'postgres'
        ? await addFilesWithUploadSession({
            matterName,
            label: label.trim(),
            files: collected,
            resumeDraft,
            onProgress: ({ uploadedFiles, totalFiles, currentPath, resumed }) => {
              if (activeMatterNameRef.current !== matterName) return;
              const prefix = resumed ? 'Resumed upload' : 'Uploaded';
              setProgressMessage(`${prefix} ${uploadedFiles}/${totalFiles} file(s). Latest: ${currentPath || 'file'}`);
              appendTerminal([`[add-files] ${resumed ? 'resumed' : 'uploaded'} ${uploadedFiles}/${totalFiles}: ${currentPath || 'file'}`]);
            },
          })
        : await addFilesWithLegacyMultipart({ matterName, label: label.trim(), files: collected });
      if (activeMatterNameRef.current !== matterName) return;
      appendTerminal([`[add-files] ${collected.length} file(s) added`]);
      onDone({ autoPrepare: (result.intakeAdded?.unique ?? collected.length) > 0 });
    } catch (err) {
      if (activeMatterNameRef.current !== matterName) return;
      reportUploadSubmitFailure({
        files: collected,
        matterName,
        view: 'add_files',
        action: 'add_files',
        error: err,
      });
      setError(getErrorMessage(err));
      appendTerminal([`[add-files] error: ${getErrorMessage(err)}`]);
    } finally {
      if (activeMatterNameRef.current === matterName) {
        setSubmitting(false);
        setProgressMessage('');
      }
    }
  }

  async function addFilesWithLegacyMultipart({
    matterName,
    label,
    files,
  }: {
    matterName: string;
    label: string;
    files: CollectedUploadFile[];
  }) {
    const fd = new FormData();
    fd.append('matterName', matterName);
    if (label) fd.append('label', label);
    fd.append('paths', JSON.stringify(files.map((c) => c.relativePath)));
    files.forEach((c) => fd.append('files', c.file, c.relativePath));
    return api.addFiles(fd);
  }

  function handleContinueWithOverlap() {
    setBypassOverlap(true);
    setSelfOverlap(null);
    setOtherOverlaps([]);
  }

  const totalSize = collected.reduce((sum, c) => sum + c.file.size, 0);
  const displayMatterName = state.activeMatter?.metadata?.matterName || state.activeMatter?.name;
  const uploadLimitCopy = describeUploadBatchLimit(state.config?.maxUploadBytes, state.config?.maxUploadFiles);

  return (
    <div className="matter-intake-shell">
      <div className="matter-intake-hero">
        <div style={{ color: 'var(--muted)', fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>
          Add Files
        </div>
        <h1 style={{ fontFamily: 'var(--display-font)', fontSize: 30, fontWeight: 500, margin: '0 0 8px', lineHeight: 1.18 }}>
          Add files to {displayMatterName}
        </h1>
        <p style={{ color: 'var(--muted)', margin: 0, fontSize: 14 }}>
          Upload source documents to the current matter.
        </p>
      </div>

      <form className="matter-intake-form" onSubmit={handleSubmit}>
        <label className="matter-intake-field">
          <span>Batch label (optional)</span>
          <input
            type="text"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="e.g. 2024 discovery batch"
            maxLength={80}
            style={{ width: '100%', background: 'var(--input-bg)', border: '1px solid var(--input-border)', color: 'var(--text)', padding: '10px 12px' }}
          />
        </label>

        <div className="matter-intake-section">
          <h2>Source files</h2>
          <div
            className={`drop-zone${dragover ? ' dragover' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setDragover(true); }}
            onDragLeave={() => setDragover(false)}
            onDrop={handleDrop}
          >
            <p style={{ margin: 0 }}>Drag & drop files or folders here</p>
            <div className="drop-actions">
              <button type="button" onClick={() => fileInput.current?.click()}>Browse files</button>
              <button type="button" onClick={() => folderInput.current?.click()}>Browse folder</button>
            </div>
            <input ref={fileInput} type="file" multiple hidden onChange={handleFileInput} />
            <input ref={folderInput} type="file" multiple hidden {...{ webkitdirectory: '' } as React.InputHTMLAttributes<HTMLInputElement>} onChange={handleFileInput} />
          </div>

          <div className="form-hint upload-limit-hint" style={{ marginTop: 10 }}>
            {uploadLimitCopy}
          </div>

          {collected.length > 0 && (
            <div className="file-list">
              <div className="file-list-summary">
                {collected.length} file{collected.length !== 1 ? 's' : ''} · {formatSize(totalSize)}
              </div>
              {collected.slice(0, 20).map((c, i) => (
                <div key={i} className="file-list-entry">{c.relativePath}</div>
              ))}
              {collected.length > 20 && (
                <div className="file-list-entry" style={{ color: 'var(--muted)' }}>
                  +{collected.length - 20} more
                </div>
              )}
            </div>
          )}
        </div>

        {runtimeUploadSessionsEnabled && recoverableUpload && (
          <UploadSessionRecoveryCard
            draft={recoverableUpload}
            selectedFiles={collected}
            onForget={() => void handleForgetRecoverableUpload()}
          />
        )}

        {selfOverlap && (
          <div className="form-info">
            <strong>Some files are already in this matter.</strong>
            <p>
              {selfOverlap.overlapCount} of {selfOverlap.totalIncoming} files match existing records.
              They'll be recorded as duplicates of the prior file ID and not re-copied.
            </p>
            <button type="button" className="run-skill-button secondary" style={{ marginTop: 8 }} onClick={handleContinueWithOverlap}>
              Continue
            </button>
          </div>
        )}

        {otherOverlaps.length > 0 && (
          <div className="form-warning">
            <h2>Files appear in other matter(s)</h2>
            <p>Some files appear in other matters. Are these meant to live here too?</p>
            <ul className="overlap-list">
              {otherOverlaps.map((o) => (
                <li key={o.matterName}>
                  <strong>{o.matterName}</strong> — {o.overlapCount} overlapping file{o.overlapCount !== 1 ? 's' : ''} ({o.overlapPercent}%)
                </li>
              ))}
            </ul>
            <div className="warning-actions">
              <button type="button" onClick={onCancel}>Cancel</button>
              <button type="button" className="secondary" onClick={handleContinueWithOverlap}>Continue adding here</button>
            </div>
          </div>
        )}

        {progressMessage && (
          <div className="form-info">
            <strong>Working…</strong>
            <p>{progressMessage}</p>
          </div>
        )}

        {error && <div className="form-error">{error}</div>}

        <div className="form-actions">
          <button type="submit" disabled={submitting || collected.length === 0}>
            {submitting ? 'Adding…' : `Add ${collected.length} file${collected.length !== 1 ? 's' : ''} to matter`}
          </button>
          <button type="button" className="secondary" onClick={onCancel}>Cancel</button>
        </div>
      </form>
    </div>
  );
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
